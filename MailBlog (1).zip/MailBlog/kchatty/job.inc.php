<?php
function send($email) {
  ini_set("SMTP", "smtp.strato.com");
  ini_set("sendmail_from", "do-not-reply@kchatty.com");

  $message = "You posted 1 or more articles on kchatty.com: https://kchatty.com/?" . $email;

  $headers = "From: do-not-reply@kchatty.com";

  mail($email, "New article posted by you", $message, $headers);
}
function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }

    if (!is_dir($dir)) {
        return unlink($dir);
    }

    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }

        if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
            return false;
        }

    }

    return rmdir($dir);
}
/* connect to server */
$hostname = '{imap.strato.com:993/imap/ssl}INBOX';
$username = 'submit@kchatty.com';
$password = '';

/* try to connect */
$inbox = imap_open($hostname,$username,$password) or die('Cannot connect: ' . imap_last_error());
$emails = imap_search($inbox,'NEW');

function clickableUrls($html){
    return preg_replace(
        '%\b(([\w-]+://?|www[.])[^\s()<>]+(?:\([\w\d]+\)|([^[:punct:]\s]|/)))%s',
        '<a href="$1">$1</a>',
        $html
    );
}

/* if emails are returned, cycle through each... */
if($emails) {

  /* begin output var */
  $output = '';
  $replied = array();

  /* put the oldest emails on top, else rsort */
  sort($emails);

  /* for every email... */
  foreach($emails as $email_number) {
    /* get information specific to this email */
    $overview = imap_fetch_overview($inbox, $email_number, 0);
    $message = clickableUrls(imap_fetchbody($inbox, $email_number, 1));
    $title = clickableUrls($overview[0]->subject);

    $name = substr($overview[0]->from, 0, -1);
    $name = substr($name, strpos($name, '<') + 1);
    $name = strtolower(trim($name));	

    $dir = "pages/" . str_replace("@", "_", str_replace(".", "-", $name)) . "/";

    if ($title == "DELETE") {
       deleteDirectory($dir);
       return;
    }

    mkdir("pages");
    mkdir($dir);
    $filename = $dir . "index.inc.html";

    if (!file_exists($filename)) {
      $contents = file_get_contents("template.inc.html");
      file_put_contents($filename, str_replace("[FROM]", $name, $contents));
    }

    $txt = '<div class="spacer"><div class="post1" alt="Title of post">' . $title . '</div>' .
      '<div class="post2" alt="Date of post">' . $overview[0]->date . '</div>' . 
      '<div class="post3" alt="Content of post">'. $message .'</div></div>';

    $myfile = str_replace("<!--INSERT-->", "<!--INSERT-->" . $txt, file_get_contents($filename));
    $myfile = file_put_contents($filename, $myfile);

    /* Send a message that says posted it. */
    if (!in_array($filename, $replied)) {
      array_push($replied, $filename);
      send($name);
    }

  }
	
  imap_delete($inbox, "1:*", $flags = 0);
  imap_expunge($inbox);
}


?>