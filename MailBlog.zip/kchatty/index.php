<?php
/*ini_set('display_errors', 'on');
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE);
ini_set('error_log', "error.log");*/

	require('job.inc.php');

	$mail = strtolower(trim($_SERVER['QUERY_STRING']));
	if (empty($mail)) {
		header("Location: https://kchatty.com/?webmaster@kchatty.com");
		die();
	}

	$contents = file_get_contents("pages/" . str_replace('@', '_', str_replace('.', '-', $mail)) . '/index.inc.html');

	if (empty($contents)) {
		$contents = file_get_contents('template.inc.html');
		$contents = str_replace('[FROM]', 'Email doesn\'t have a page yet. ' . 
			'<a href="mailto:o@kchatty.com">Submit an article</a> if this is your email', $contents);
	}

	echo $contents;
?>

