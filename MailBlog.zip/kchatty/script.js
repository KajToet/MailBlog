var emptyMail = "name@domain.com";

document.getElementById("go").onclick = function() {
	var val = document.getElementById("email").value;
	if (val != emptyMail) {
		if (val == "") {
			document.getElementById("email").value = emptyMail;
		} else {
			document.location.href = "https://kchatty.com/?" + val;
		}
	}
}

document.getElementById("email").value = emptyMail;
document.getElementById("email").onclick = function() {
	var val = document.getElementById("email").value;
	if (val == emptyMail) {
		document.getElementById("email").value = "";
	}
}
